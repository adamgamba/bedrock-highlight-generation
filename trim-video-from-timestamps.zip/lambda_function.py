import json
import boto3

# Starts two MediaConvert jobs with the given timestamps (20s) clips
def lambda_handler(event, context):
    
    # payload = {
    #     "timestamps": new_timestamps,
    #     "descriptions": descriptions,
    #     "file_names": file_names
    #     "long_video_filename": long_video_filename
    # }
    
    print(json.dumps(event))
    timestamps = event["timestamps"]
    descriptions = event["descriptions"]
    file_names = event["file_names"]

    long_video_filename = event["long_video_filename"]

    for i in range(len(timestamps) ):
      end_timestamp = add_seconds_to_timestamp(timestamps[i], 20)
      start_timestamp = remove_seconds_from_timestamp(timestamps[i], 20)
      clip_filename = start_timestamp + "-" + file_names[i].split('.')[0]
      description = descriptions[i]
      response = trim_video(start_timestamp, end_timestamp, long_video_filename, clip_filename)
      print("response", response)

    end_timestamps = [add_seconds_to_timestamp(timestamp, 20) for timestamp in timestamps]
    start_timestamps = [remove_seconds_from_timestamp(timestamp, 20) for timestamp in timestamps]
    response_2 = trim_videos(start_timestamps, end_timestamps, long_video_filename)
    print("response 2", response_2)
    
    
def add_seconds_to_timestamp(timestamp, num_seconds):
    timestamp = timestamp.replace(",", ":")

    # Split the timestamp into hours, minutes, and seconds
    hours, minutes, seconds, _ = map(int, timestamp.split(':'))

    # Add num_seconds
    seconds += num_seconds

    # Handle overflow if seconds exceeds 59
    if seconds >= 60:
        minutes += 1
        seconds -= 60

    # Handle overflow if minutes exceeds 59
    if minutes >= 60:
        hours += 1
        minutes -= 60

    # Format the new timestamp
    new_timestamp = f"{hours:02d}:{minutes:02d}:{seconds:02d}:00"

    return new_timestamp

def remove_seconds_from_timestamp(timestamp, num_seconds):
    timestamp = timestamp.replace(",", ":")

    # Split the timestamp into hours, minutes, and seconds
    hours, minutes, seconds, _ = map(int, timestamp.split(':'))

    if hours == 0 and minutes == 0 and seconds < num_seconds:
      seconds = 0
      # Format the new timestamp
      new_timestamp = f"{hours:02d}:{minutes:02d}:{seconds:02d}:00"
  
      print("new timestamp: ", new_timestamp)
      return new_timestamp
    
    # Remove num_seconds
    seconds -= num_seconds
    
    
    # Handle underflow if seconds become negative
    if seconds < 0:
        minutes -= 1
        seconds += 60

    # Handle underflow if minutes become negative
    if minutes < 0:
        hours -= 1
        minutes += 60

    # Ensure hours, minutes, and seconds are within valid ranges
    hours = max(0, hours)
    minutes = max(0, minutes)
    seconds = max(0, seconds)

    # Format the new timestamp
    new_timestamp = f"{hours:02d}:{minutes:02d}:{seconds:02d}:00"

    print("new timestamp: ", new_timestamp)
    return new_timestamp


def trim_video(start, end, long_video_filename, filename):
    mediaconvert = boto3.client('mediaconvert', region_name='us-west-2')

    job_settings = {
      "Queue": "arn:aws:mediaconvert:us-west-2:028607317402:queues/Default",
       "UserMetadata": {},
      # "Role": "arn:aws:iam::028607317402:role/service-role/ab3-trim-video-from-timestamps-role-t8p9iu1e",
      "Role": "arn:aws:iam::028607317402:role/service-role/MediaConvert_Default_Role",
      "Settings": {
        "TimecodeConfig": {
          "Source": "ZEROBASED"
        },
        "OutputGroups": [
          {
            "Name": "File Group",
            "Outputs": [
              {
                "ContainerSettings": {
                  "Container": "MP4",
                  "Mp4Settings": {}
                },
                "VideoDescription": {
                  "CodecSettings": {
                    "Codec": "H_264",
                    "H264Settings": {
                      "MaxBitrate": 5000000,
                      "RateControlMode": "QVBR",
                      "SceneChangeDetect": "TRANSITION_DETECTION"
                    }
                  }
                },
                "AudioDescriptions": [
                  {
                    "CodecSettings": {
                      "Codec": "AAC",
                      "AacSettings": {
                        "Bitrate": 96000,
                        "CodingMode": "CODING_MODE_2_0",
                        "SampleRate": 48000
                      }
                    }
                  }
                ]
              }
            ],
            "OutputGroupSettings": {
              "Type": "FILE_GROUP_SETTINGS",
              "FileGroupSettings": {
                "Destination": "s3://agamba-ab3-clips/" + filename
              }
            }
          }
        ],
        # "FollowSource": 1,
        "Inputs": [
              {
                "InputClippings": [
              {
                "EndTimecode": end,
                "StartTimecode": start
              }
            ],
            "AudioSelectors": {
              "Audio Selector 1": {
                "DefaultSelection": "DEFAULT"
              }
            },
            "VideoSelector": {},
            "TimecodeSource": "ZEROBASED",
            "FileInput": "s3://agamba-ab3-long-videos/" + long_video_filename
          }
        ]
      },
      "BillingTagsSource": "JOB",
      "AccelerationSettings": {
        "Mode": "DISABLED"
      },
      "StatusUpdateInterval": "SECONDS_60",
      "Priority": 0
    }


    # Create the MediaConvert job
    response = mediaconvert.create_job(**job_settings)
    print(response)

    return response

def trim_videos(starts, ends, long_video_filename):
    mediaconvert = boto3.client('mediaconvert', region_name='us-west-2')

    timecodes = []
    for i in range(len(starts)):
      timecodes.append(
        {
          "EndTimecode": ends[i],
          "StartTimecode": starts[i]
        }
      )
    
    print("timecodes: ", timecodes)

    # {
    #   "EndTimecode": end,
    #   "StartTimecode": start
    # }


    job_settings = {
      "Queue": "arn:aws:mediaconvert:us-west-2:028607317402:queues/Default",
       "UserMetadata": {},
      # "Role": "arn:aws:iam::028607317402:role/service-role/ab3-trim-video-from-timestamps-role-t8p9iu1e",
      "Role": "arn:aws:iam::028607317402:role/service-role/MediaConvert_Default_Role",
      "Settings": {
        "TimecodeConfig": {
          "Source": "ZEROBASED"
        },
        "OutputGroups": [
          {
            "Name": "File Group",
            "Outputs": [
              {
                "ContainerSettings": {
                  "Container": "MP4",
                  "Mp4Settings": {}
                },
                "VideoDescription": {
                  "CodecSettings": {
                    "Codec": "H_264",
                    "H264Settings": {
                      "MaxBitrate": 5000000,
                      "RateControlMode": "QVBR",
                      "SceneChangeDetect": "TRANSITION_DETECTION"
                    }
                  }
                },
                "AudioDescriptions": [
                  {
                    "CodecSettings": {
                      "Codec": "AAC",
                      "AacSettings": {
                        "Bitrate": 96000,
                        "CodingMode": "CODING_MODE_2_0",
                        "SampleRate": 48000
                      }
                    }
                  }
                ]
              }
            ],
            "OutputGroupSettings": {
              "Type": "FILE_GROUP_SETTINGS",
              "FileGroupSettings": {
                "Destination": "s3://agamba-ab3-clips/highlight-reel-" + long_video_filename
              }
            }
          }
        ],
        # "FollowSource": 1,
        "Inputs": [
              {
                "InputClippings": timecodes,
            "AudioSelectors": {
              "Audio Selector 1": {
                "DefaultSelection": "DEFAULT"
              }
            },
            "VideoSelector": {},
            "TimecodeSource": "ZEROBASED",
            "FileInput": "s3://agamba-ab3-long-videos/" + long_video_filename
          }
        ]
      },
      "BillingTagsSource": "JOB",
      "AccelerationSettings": {
        "Mode": "DISABLED"
      },
      "StatusUpdateInterval": "SECONDS_60",
      "Priority": 0
    }


    # Create the MediaConvert job
    response = mediaconvert.create_job(**job_settings)
    print(response)

    return response





