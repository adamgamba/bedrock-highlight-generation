import datetime
import json
import boto3

def lambda_handler(event, context):    
    # print(json.dumps(event))

    # Read full S3 file path from S3 event notification
    input_bucket_name = event['Records'][0]['s3']['bucket']['name']
    file_path = event['Records'][0]['s3']['object']['key']
    
    # Output bucket name
    output_bucket_name = 'agamba-ab3-clips'

    # # File name is the last part of the file path
    # file_name = file_path.split('/')[-1]
    # file_name_minus_extension = file_name.split('.')[-1]

    # Read SRT file from S3
    s3 = boto3.client('s3')
    srt_file = s3.get_object(Bucket=input_bucket_name, Key=file_path)
    srt_content = srt_file['Body'].read().decode('utf-8')
    # print(srt_content)

    # Read content from a local text file
    # Copy its contents to post_prompt variable
    with open('post-transcript-prompt.txt', 'r') as file:
        post_prompt = file.read()
    # print(post_prompt)

    completion = invoke_claude(srt_content + post_prompt)
    # print("-----")
    # print(completion)
    # print("-----")
    
    numbers, timestamps, descriptions, file_names = parse_completion(completion)
    new_timestamps = convert_timestamps_to_mediaconvert_format(timestamps)
    print(new_timestamps)

    # Trigger a lambda function with payload
    long_video_filename = file_path.split(".")[0] + ".mp4" #"fastest-goal.mp4" # ! TODO
    payload = {
        "timestamps": new_timestamps,
        "descriptions": descriptions,
        "file_names": file_names,
        "long_video_filename": long_video_filename
    }
    # Invoke lambda function async
    lambda_client = boto3.client('lambda')
    lambda_client.invoke(
        FunctionName='ab3-trim-video-from-timestamps',
        InvocationType='Event',
        Payload=json.dumps(payload)
    )
    print(json.dumps(payload))
    return

def convert_timestamps_to_mediaconvert_format(timestamps):
    new_timestamps = []
    for ts in timestamps:
        new_ts = ts.split(".")[0].split(",")[0] + ":00"
        new_timestamps.append(new_ts)
    
    return new_timestamps     
    

def parse_completion(completion):
    print("completion: ", completion)
    # Initialize lists to store data
    numbers = []
    timestamps = []
    descriptions = []
    file_names = []
    
    # Split the string by newlines to get individual lines
    lines = completion.split('\n')
    # Remove whitespace elements
    lines = [s for s in lines if s.strip() != ""]
    
    # Iterate over lines in groups of 4
    for i in range(0, len(lines), 4):
        # Extract data from each line
        number = lines[i].strip()
        timestamp = lines[i + 1].strip()
        description = lines[i + 2].strip()
        file_name = lines[i + 3].strip()
        
        # Append extracted data to respective lists
        numbers.append(number)
        timestamps.append(timestamp)
        descriptions.append(description)
        file_names.append(file_name)
    
    # Print the lists to verify the data
    print("Numbers:", numbers)
    print("Timestamps:", timestamps)
    print("Descriptions:", descriptions)
    print("File Names:", file_names)
    
    return numbers, timestamps, descriptions, file_names


def invoke_claude(prompt):
    """
    Invokes the Anthropic Claude 2 model to run an inference using the input
    provided in the request body.

    :param prompt: The prompt that you want Claude to complete.
    :return: Inference response from the model.
    """

    bedrock_client = boto3.client('bedrock-runtime')

    # The different model providers have individual request and response formats.
    # For the format, ranges, and default values for Anthropic Claude, refer to:
    # https://docs.aws.amazon.com/bedrock/latest/userguide/model-parameters-claude.html

    # Claude requires you to enclose the prompt as follows:
    enclosed_prompt = "Human: " + prompt #+ "\n\nAssistant:"

    # Claude 2
    body = {
        "prompt": enclosed_prompt,
        "max_tokens_to_sample": 1000,
        "temperature": 0.1,
        "stop_sequences": ["\n\nHuman:"],
    }

    response = bedrock_client.invoke_model(
        modelId="anthropic.claude-instant-v1", body=json.dumps(body)
    )

    response_body = json.loads(response["body"].read())
    completion = response_body["completion"]

    return completion
    
    
    # ## new attempt (claude 3 - not ready)
    # model_id = "anthropic.claude-3-sonnet-20240229-v1:0"
    # response = bedrock_client.invoke_model(
    #             modelId=model_id,
    #             body=json.dumps(
    #                 {
    #                     "anthropic_version": "bedrock-2023-05-31",
    #                     "max_tokens": 1024,
    #                     "messages": [
    #                         {
    #                             "role": "user",
    #                             "content": [{"type": "text", "text": enclosed_prompt}],
    #                         }
    #                     ],
    #                 }
    #             ),
    #         )

    # result = json.loads(response.get("body").read())
    # input_tokens = result["usage"]["input_tokens"]
    # output_tokens = result["usage"]["output_tokens"]
    # output_list = result.get("content", [])

    # print("Invocation details:")
    # print(f"- The input length is {input_tokens} tokens.")
    # print(f"- The output length is {output_tokens} tokens.")

    # # print(f"- The model returned {len(output_list)} response(s):")
    # completion = output_list[0]["text"]
    # # for output in output_list:
    # #     print(output["text"])

    # return output_list[0]




