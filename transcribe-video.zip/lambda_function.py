import datetime
import json
import boto3

def lambda_handler(event, context):
    print(json.dumps(event))

    # Read full S3 file path from S3 event notification
    input_bucket_name = event['Records'][0]['s3']['bucket']['name']
    file_path = event['Records'][0]['s3']['object']['key'] # Ex. long-videos/fastest-goal.mp4
    
    # Output bucket name
    output_bucket_name = 'agamba-ab3-transcripts'

    # File name is the last part of the file path
    file_name = file_path.split('/')[-1]
    file_name_minus_extension = file_name.split('.')[0]

    # Start a Transcribe job on the above mp4 file
    transcribe = boto3.client('transcribe')
    # Get the current datetime
    current_datetime = datetime.datetime.now()

    # Format the datetime object without spaces
    formatted_datetime = current_datetime.strftime('%Y-%m-%d_%H-%M-%S')

    transcribe.start_transcription_job(
        # Job name is file_path with appended current datetime
        TranscriptionJobName=file_name_minus_extension + '-' +  formatted_datetime,
        Media={'MediaFileUri': 's3://' + input_bucket_name + '/' + file_path},
        MediaFormat='mp4',
        # Enable automatic language identification
        IdentifyLanguage=True,
        # Output file location in S3 bucket
        OutputBucketName=output_bucket_name,
        # Output file name is the same as the input file name
        OutputKey=file_name_minus_extension,
        # Enable SRT subtitles
        Subtitles={
            'Formats': ['srt'],
            'OutputStartIndex': 1
        }
    )
    

